﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Http.Controllers;
using System.Web.Mvc;
using PortalAPI.Models;

namespace POMS.Controllers
{
    public class MyActionFilterAttribute : System.Web.Http.Filters.ActionFilterAttribute
    {
        public override void OnActionExecuting(HttpActionContext actionContext)
        {
            var tkn = HttpContext.Current.Request.Headers.GetValues("Token");
            Portal_RegistrationEntities DS = new Portal_RegistrationEntities();
            Portal_AccessToken ATN = new Portal_AccessToken();

            var tknid = new Guid(tkn[0]);
           // var a = DS.Portal_State.Where(PS => PS.CountryCode == 1).ToList();

            var at = DS.Portal_AccessToken.
                Where(t => t.TokenID == tknid).FirstOrDefault();
            string UID = Convert.ToString(at.UserID);
            //HttpContext.Current.Session["UID"] = UID;
            HttpContext.Current.Request.Headers.Add("UID", UID);
            base.OnActionExecuting(actionContext);
        }
        
       
    }
}