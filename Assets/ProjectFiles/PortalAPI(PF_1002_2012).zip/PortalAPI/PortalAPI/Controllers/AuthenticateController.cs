﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Script.Serialization;
using POMS.Controllers;
using PortalAPI.Models;

namespace PortalAPI.Controllers
{
    public class AuthenticateController : ApiController
    {
       
        // GET api/authenticate
        public IEnumerable<string> Get(Credentials CD1)
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/authenticate/5
        
        public List<LoginCheck_Result1> Post ()
        {
                        
            var queryString = this.Request.GetQueryNameValuePairs();
            var parameterval = queryString.ToList()[0].Value;

            JavaScriptSerializer json_serializer = new JavaScriptSerializer();
            Credentials CD = new Credentials();
            CD = json_serializer.Deserialize<Credentials>(parameterval);

            Portal_RegistrationEntities DS = new Portal_RegistrationEntities();
            List<LoginCheck_Result1> res = DS.LoginCheck(CD.UserID, CD.Password,CD.Source).ToList<LoginCheck_Result1>();
            return res;
        }

        // POST api/authenticate
       

        // PUT api/authenticate/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/authenticate/5
        public void Delete(int id)
        {
        }
    }
}
