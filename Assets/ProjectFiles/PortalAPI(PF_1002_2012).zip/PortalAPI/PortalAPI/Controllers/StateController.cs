﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using POMS.Controllers;
using PortalAPI.Models;

namespace PortalAPI.Controllers
{
    [MyActionFilter]
    public class StateController : ApiController
    {
        Portal_RegistrationEntities DS = new Portal_RegistrationEntities();
        // GET api/state
        public IEnumerable<Portal_State> Get()
        {
            

            return DS.Portal_State.ToList();
        }

        // GET api/state/5
        public List<Portal_State> Get(int id)
        {
            
            var UID = HttpContext.Current.Request.Headers.GetValues("UID");

            return DS.Portal_State.Where(PS => PS.CountryCode == id).ToList();
        }

        // POST api/state
        public List<Portal_State> Post([FromBody]string value)
        {

            var UID = HttpContext.Current.Request.Headers.GetValues("UID");
            //Get mode to return all state or country wise state
            var Mode = Request.Headers.GetValues("MODE");
            string[] m = (string[])Mode;
            if (m[0] == "GETALL")
            {
                
                return DS.Portal_State.ToList();
            }
            else
            {
                var id = HttpContext.Current.Request.Headers.GetValues("ID");
                return DS.Portal_State.Where(PS => PS.CountryCode == Convert.ToInt16(id)).ToList();
            }
           
        }

        // PUT api/state/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/state/5
        public void Delete(int id)
        {
        }
    }
}
