﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using PortalAPI.Models;

namespace PortalAPI.Controllers
{
    public class RegistrationController : ApiController
    {
        // GET api/registration
        public IEnumerable<string> Get()
        {
            

            return new string[] {""};
        }

        // GET api/registration/5
        public string Get(int id)
        {
            return "value";
        }

        // POST api/registration
        public void Post([FromBody]string value)
        {
        }

        // PUT api/registration/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/registration/5
        public void Delete(int id)
        {
        }
    }
}
