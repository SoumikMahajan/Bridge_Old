﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PortalAPI.Models
{
    public class Models
    {
        
    }
    public class Credentials
    {
       public string UserID { get; set; }
       public string Password { get; set; }
       public string Source { get; set; }
    }
}